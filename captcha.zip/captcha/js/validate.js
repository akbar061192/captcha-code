function validate() {
  var Password = document.getElementById('password').value;
  var responseToken = grecaptcha.getResponse();

  if (responseToken) {
    document.getElementById('cap-msg').innerHTML = '';
  }
  if (Password === 'CAOneTechCloud') {
    document.getElementById('messeges').innerHTML = '';
  }
  if (Password === 'CAOneTechCloud' && responseToken) {
    window.location.href = '../main.html';
  } else {
    if (!responseToken && Password !== 'CAOneTechCloud') {
      document.getElementById('cap-msg').innerHTML = 'Please verify the captcha';
      document.getElementById('messeges').innerHTML = '**wrong password please try again...';
    } else if (!responseToken) {
      document.getElementById('cap-msg').innerHTML = 'Please verify the captcha';
    } else {
      document.getElementById('messeges').innerHTML = '**wrong password please try again...';
    }
  }
}
